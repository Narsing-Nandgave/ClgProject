import mysql from "mysql";
import express from "express";
import bodyparser from "body-parser";
import ejs from "ejs";

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "Rushikesh15pawar11@",
    database: "hotel"
});
connection.connect((err, data) => {
    if (err) {
        console.log(err);
        console.log("can't connect server");
    } else {
        console.log("connection to server is done ");
    }
});

const dir = "C:\\Users\\ASUS\\Desktop\\WebDevlopment\\Projects\\food-delivery";
const app = express();

app.use(express.static(dir));
app.engine('html',ejs.renderFile);
app.set('view engine','html');
app.use(bodyparser.urlencoded({ extended: true }));



app.get("/", (req, res) => {
    res.sendFile(dir+"//index.html");
})
app.post("/adminlogin",(req,res)=>{
    var email=req.body.email;
    var pass=req.body.password;
    var query=`SELECT * FROM hadmin WHERE eemail='${email}' and epassword='${pass}'`;
    connection.query(query,(err,data)=>{
        res.sendFile(dir+"//adminhome.html")
    });
    
});
app.post("/employeelogin",(req,res)=>{
    var email=req.body.email;
    var pass=req.body.password;
    var query=`SELECT * FROM employee WHERE aemail='${email}' and apassword='${pass}'`;
    connection.query(query,(err,data)=>{
        res.sendFile(dir+"///employee-home.html");
    });
});
app.post("/formdata", (req, res) => {
    const name = req.body.name;
    const mail = req.body.mail;
    const contact = req.body.contact;
    const msg = req.body.message;
    connection.query(`INSERT INTO foodweb VALUES ('${name}','${mail}','${contact}','${msg}')`)
    res.end("<h1>Your data is accepted but your devloper Master rushikesh pawar does not create any page to show display.</h1>");
});
app.get("/getemployeeinfo/:email",(req,res)=>{
    var email=req.params.email;
    var query=`SELECT * FROM  employee WHERE eemail='${email}' `;
    connection.query(query,(err,data)=>{
        res.send(JSON.stringify(data));
    });
});

app.get("/getfeedback/:email",(req,res)=>{
    var email=req.params.email;
    var query=`SELECT * FROM servicefeedback as s,managementfeedback as m,aboutpayment as a WHERE a.apemail=m.memail AND m.memail=s.semail AND s.semail='${email}'`;
    connection.query(query,(err,data)=>{
        res.send(JSON.stringify(data));
    })
})

app.get("/feedbackanalysis",(req,res)=>{
    var sdata={};
    var total=0;
    var yesswifi=0;
    var yessfamilyi=0;
    var yessfirei=0;
    var yessaccessoriesi=0;
    var yesshealthi=0;
    var yesstravela=0;
    var yessrechargea=0;
    var yessfooda=0;
    var yessuniform=0;
    var yessloanprovided=0;
    var intrest={};
    var mtranning={};
    var yesmartisticenvironment=0;
    var yesmskillfullenvironment=0;
    var yesmcommunicationenvironment=0;
    var yesmteamworkenvironment=0;
    var msupportsystem={};
    var apsalarytimming={};
    var apallowances={};
    var apbonusonoccasions={};
    var apinsurancerate={};

    var query=`SELECT COUNT(*) as count FROM servicefeedback`;
    var query1=`SELECT COUNT(*) as count FROM servicefeedback WHERE swifi='yes'`;
    var query2=`SELECT COUNT(*) AS count FROM servicefeedback WHERE sfamilyi='yes'`;    
    var query3=`SELECT COUNT(*) AS count FROM servicefeedback WHERE sfirei='yes'`;
    var query4=`SELECT COUNT(*) AS count FROM servicefeedback WHERE saccessoriesi='yes'`;
    var query5=`SELECT COUNT(*) AS count FROM servicefeedback WHERE shealthi='yes'`;
    var query6=`SELECT COUNT(*) AS count FROM servicefeedback WHERE stravela='yes'`;
    var query7=`SELECT COUNT(*) AS count FROM servicefeedback WHERE srechargea='yes'`;
    var query8=`SELECT COUNT(*) AS count FROM servicefeedback WHERE sfooda='yes'`;    
    var query9=`SELECT COUNT(*) AS count FROM servicefeedback WHERE suniform='yes'`;    
    var query10=`SELECT COUNT(*) AS count FROM servicefeedback WHERE sloanprovided='yes'`;    
    var query11=`SELECT sintrestrate,COUNT(*) AS count FROM servicefeedback GROUP BY sintrestrate `;   
    var query12=`SELECT mtranning,COUNT(*) AS count FROM managementfeedback GROUP BY mtranning`;
    var query13=`SELECT COUNT(*) AS count FROM managementfeedback WHERE martisticenvironment='yes'`;
    var query14=`SELECT COUNT(*) AS count FROM managementfeedback WHERE mskillfullenvironment='yes'`;
    var query15=`SELECT COUNT(*) AS count FROM managementfeedback WHERE mcommunicationenvironment='yes'`;
    var query16=`SELECT COUNT(*) AS count FROM managementfeedback WHERE mteamworkenvironment='yes'`;
    var query17=`SELECT msupportsystem,COUNT(*) AS count FROM managementfeedback GROUP BY msupportsystem`;
    var query18=`SELECT apsalarytimming ,COUNT(*) AS count FROM aboutpayment GROUP BY apsalarytimming`;
    var query19=`SELECT  apallowances,COUNT(*) AS count FROM aboutpayment GROUP BY apallowances`;
    var query20=`SELECT apbonusonoccasions ,COUNT(*) AS count FROM aboutpayment GROUP BY apbonusonoccasions`;
    function execute(){
        connection.query(query,(err,data)=>{
            total=data[0]['count'];
            sdata["total"]=total;
            connection.query(query1,(err,data)=>{
                yesswifi=data[0]['count'];
                sdata["yesswifi"]= yesswifi;
                connection.query(query2,(err,data)=>{
                    yessfamilyi=data[0]['count'];
                    sdata["yessfamilyi"]=yessfamilyi;
                    connection.query(query3,(err,data)=>{
                        yessfirei=data[0]['count'];
                        sdata["yessfirei"]=yessfirei;
                        connection.query(query4,(err,data)=>{
                            yessaccessoriesi=data[0]['count'];
                            sdata["yessaccessoriesi"]=yessaccessoriesi;
                            connection.query(query5,(err,data)=>{
                                yesshealthi=data[0]['count'];
                                sdata["yesshealthi"]=yesshealthi;
                                connection.query(query6,(err,data)=>{
                                      yesstravela=data[0]['count'];
                                      sdata["yesstravela"]=yesstravela;
                                    connection.query(query7,(err,data)=>{
                                        yessrechargea=data[0]['count'];
                                        sdata["yessrechargea"]=yessrechargea;
                                        connection.query(query8,(err,data)=>{
                                            yessfooda=data[0]['count'];
                                            sdata["yessfooda"]=yessfooda;
                                            connection.query(query9,(err,data)=>{
                                                yessuniform=data[0]['count'];
                                                sdata["yessuniform"]=yessuniform;
                                                connection.query(query10,(err,data)=>{
                                                    yessloanprovided=data[0]['count'];
                                                    sdata["yessloanprovided"]=yessloanprovided;
                                                    connection.query(query11,(err,data)=>{
                                                        for(let i=0;i<data.length;i++){
                                                            var newdata=data[i];
                                                            intrest[newdata['sintrestrate']]=newdata['count']
                                                        }
                                                        sdata["intrest"]=intrest;
                                                        executemanagment();
                                                    })

                                                })
                                            })
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
            });
        });
     

        
    }
    function executemanagment(){
        connection.query(query12,(err,data)=>{
            for(let i=0;i<data.length;i++){
                var newdata=data[i];
                mtranning[newdata['mtranning']]=newdata['count']
            }
            sdata["mtranning"]=mtranning;
            connection.query(query13,(err,data)=>{
                yesmartisticenvironment=data[0]['count'];
                sdata["yesmartisticenvironment"]=yesmartisticenvironment;
                connection.query(query14,(err,data)=>{
                    yesmskillfullenvironment=data[0]['count'];
                    sdata["yesmskillfullenvironment"]=yesmskillfullenvironment;
                    connection.query(query15,(err,data)=>{
                        yesmcommunicationenvironment=data[0]['count'];
                        sdata["yesmcommunicationenvironment"]=yesmcommunicationenvironment;
                        connection.query(query16,(err,data)=>{
                            yesmteamworkenvironment=data[0]['count'];
                            sdata["yesmteamworkenvironment"]=yesmteamworkenvironment;
                            connection.query(query17,(err,data)=>{
                                for(let i=0;i<data.length;i++){
                                    var newdata=data[i];
                                    msupportsystem[newdata['msupportsystem']]=newdata['count']
                                }
                                sdata["msupportsystem"]=msupportsystem;
                                executeaboutpayment();
                            })
                        })
                        
                    })
                    
                })
            })

               
        })
    }
    function executeaboutpayment(){
        connection.query(query18,(err,data)=>{
            for(let i=0;i<data.length;i++){
                var newdata=data[i];
                apsalarytimming[newdata['apsalarytimming']]=newdata['count'];
            }
            sdata["apsalarytimming"]=apsalarytimming;
            connection.query(query19,(err,data)=>{
                for(let i=0;i<data.length;i++){
                    var newdata=data[i];
                    apallowances[newdata['apallowances']]=newdata['count'];
                }
                sdata["apallowances"]=apallowances;
                connection.query(query20,(err,data)=>{
                    for(let i=0;i<data.length;i++){
                        var newdata=data[i];
                        apbonusonoccasions[newdata['apbonusonoccasions']]=newdata['count'];
                    }
                    sdata["apbonusonoccasions"]=apbonusonoccasions;
                    res.send(JSON.stringify(sdata));
                });
            });
        });
    }
      
     execute();
  
    
})

app.post("/submitfeedback",(req,res)=>{
    var email=req.body.email;
    // direct value
    var swifi=req.body.wifi;
    // yes no for each
    var sfamilyi=req.body.ifamily;
    var sfirei=req.body.IFire;
    var saccessoriesi=req.body.IAccessories;
    var shealthi=req.body.IHealth;
    // yes no type
    var stravela=req.body.ATravel;
    var srechargea=req.body.ARecharge;
    var sfooda=req.body.AFood;
    var suniform=req.body.AUniform;
    var sloanprovided=req.body.Loan;
    // only single
    var sintrestrate=req.body.IRate;



    var mtranning=req.body.Tranning;
    var martisticenvironment=req.body.Artistic;
    var mskillfullenvironment=req.body.Skillfull;
    var mcommunicationenvironment=req.body.Communicationfocused;
    var mteamworkenvironment=req.body.TeamWork;
    var msupportsystem=req.body.SupportStaff;
    var mreviewaboutmanagement=req.body.Review;
    var apsalarytimming=req.body.Salray;
    var apallowances=req.body.Allowance;
    var apbonusonoccasions=req.body.Bonus;
    var apinsurancerate =req.body.rating;
    if(apinsurancerate>10)
    apinsurancerate=10;
    if(apinsurancerate<0)
    apinsurancerate=0;
    if(sfamilyi=="on"){
        sfamilyi="yes";
    }
    else{
        sfamilyi="no";
    }
    if(sfirei=="on"){
        sfirei="yes";
    }
    else{
        sfirei="no";
    }
    if(saccessoriesi=="on"){
        saccessoriesi="yes";
    }
    else{
        saccessoriesi="no";
    }
    if(shealthi=="on"){
        shealthi="yes";
    }
    else{
        shealthi="no";
    }
    if(stravela=="on"){
        stravela="yes";
    }
    else{
        stravela="no";
    }
    if(srechargea=="on"){
        srechargea="yes";
    }
    else{
        srechargea="no";
    }
    if(sfooda=="on"){
        sfooda="yes";
    }
    else{
        sfooda="no";
    }
    if(suniform=="on"){
        suniform="yes";
    }
    else{
        suniform="no";
    }
    // For second table
    if(martisticenvironment=="on")
    {
        martisticenvironment="yes";
    }
    else
    {
        martisticenvironment="no";
    }

    if(mskillfullenvironment=="on")
    {
        mskillfullenvironment="yes";
    }
    else
    {
        mskillfullenvironment="no";
    }
    if(mcommunicationenvironment=="on")
    {
        mcommunicationenvironment="yes";
    }
    else
    {
        mcommunicationenvironment="no";
    }
    if( mteamworkenvironment=="on")
    {
        mteamworkenvironment="yes";
    }
    else
    {
        mteamworkenvironment="no";
    }

    connection.query(`DELETE FROM servicefeedback WHERE semail='${email}'`,(err,date)=>{
        connection.query(`DELETE FROM managementfeedback WHERE memail='${email}'`,(err,data)=>{
            connection.query(`DELETE FROM aboutpayment WHERE apemail='${email}'`,(err,data)=>{
                addfeedback();
            })
        })
    })
    function addfeedback(){
        var query1=`INSERT INTO servicefeedback VALUES ('${email}','${swifi}','${sfamilyi}','${sfirei}','${saccessoriesi}','${shealthi}','${stravela}','${srechargea}','${sfooda}','${suniform}','${sloanprovided}','${sintrestrate}')`;
        var query2=`INSERT INTO managementfeedback VALUES('${email }','${mtranning }','${martisticenvironment }','${mskillfullenvironment }','${mcommunicationenvironment }','${mteamworkenvironment }','${mreviewaboutmanagement }','${msupportsystem}')`
        var query3=`INSERT INTO aboutpayment VALUES ('${email}','${apsalarytimming}','${apallowances}','${apbonusonoccasions}','${apinsurancerate}')`
        connection.query(query1,(err,data)=>{
            connection.query(query2,(err,data)=>{
                connection.query(query3,(err,data)=>{
                    res.sendFile(dir+"//employee-home.html")
                })
            })

        })
    }

});

app.post("/addemployee",(req,res)=>{
    // Employee table
var eemail=req.body.email;
var epassword =req.body.password;
var efname =req.body.fname;
var elaname=req.body.lname;
var edob=req.body.dob;
var date=new Date();
var ejoindate =`${date.getFullYear()}-${date.getMonth()+1}-${date.getDate()}`;
var esalry=req.body.salary;
var eeduaction =req.body.education;
var epost =req.body.post;
var egneder =req.body.gender;
var econtact1 =req.body.contact1;
var econtact2=req.body.contact2;
var epaddress =req.body.paddress;
var etaddress =req.body.taddress;
var query=`INSERT INTO employee VALUES('${eemail}','${epassword}','${efname}','${elaname}','${edob}','${ejoindate}',${esalry},'${eeduaction}','${epost}','${egneder}','${econtact1}','${econtact2}','${epaddress}','${etaddress}')`;
connection.query(query,(err,data)=>{
    res.sendFile(dir+"//adminhome.html");
});
});

app.listen(8000);